package comoycomo;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.sql.SQLException;

import javax.swing.JOptionPane;

public class Client implements Runnable{
	private Socket s;
	private ObjectOutputStream oos;
	private ObjectInputStream ois;
	private OracleConnection bdConnection;
	private ComoyComo ventana;

	public Client(OracleConnection bdConnection, ComoyComo ventana){
		this.bdConnection=bdConnection;
		this.ventana=ventana;
	}
	
	@Override
	public void run() {
		try {
			s = new Socket(JOptionPane.showInputDialog("Ingrese la direc�n IP del servidor"), 9999);
			oos = new ObjectOutputStream(s.getOutputStream());
			ois = new ObjectInputStream(s.getInputStream());
			JOptionPane.showMessageDialog(null, "Conexi�n exitosa con el servidor", "COMO&COMO Cliente", JOptionPane.INFORMATION_MESSAGE);
			this.readLine();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void readLine(){
		while(true){
			Object aux;
			try {
				aux = ois.readObject();
				if(aux != null && aux instanceof String){
					bdConnection.getStament().executeUpdate(""+aux);
					ventana.fillAllTables();
				}
				Thread.sleep(30);
			}catch(InterruptedException | ClassNotFoundException | IOException | SQLException e){
				e.printStackTrace();
			}
		}
	}
	
	public void writeLine(String query){
		try{
			oos.writeObject(query);
		}catch(IOException e){
			e.printStackTrace();
		}
	}
	
	public void closeConenction(){
		try{
			oos.close();
			ois.close(); 
			s.close();
		}catch(Exception e){
			e.printStackTrace();
		}
	}
}

package comoycomo;

public class MainComoyComo {

	public static void main(String[] args) {
		ComoyComo v = new ComoyComo("COMO&COMO Cliente: Bienvenido");
		v.setVisible(true);
	}
}
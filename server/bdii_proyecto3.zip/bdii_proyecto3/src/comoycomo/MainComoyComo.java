package comoycomo;

public class MainComoyComo {

	public static void main(String[] args) {
		ComoyComo v = new ComoyComo("COMO&COMO Servidor: Bienvenido");
		v.setVisible(true);
	}
}
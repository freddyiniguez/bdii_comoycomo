package comoycomo;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.sql.SQLException;

import javax.swing.JOptionPane;

public class Server implements Runnable{
	private ServerSocket ss;		// Socket servidor
	private Socket s;				// Socket cliente
	private ObjectOutputStream oos; // Enviar objetos
	private ObjectInputStream ois; 	// Recibir objetos
	private OracleConnection bdConnection; 	// Conexi�n a Oracle
	private ComoyComo ventana; 		// Interfaz gr�fica
	
	public Server(OracleConnection bdConnection, ComoyComo ventana){
		this.bdConnection=bdConnection;
		this.ventana=ventana;
	}
	
	@Override
	public void run() {
		try {
			ss = new ServerSocket(9999); // Crea un nuevo socket servidor
			s = ss.accept();			 // Acepta la entrada de un socket cliente
			oos = new ObjectOutputStream(s.getOutputStream());
			ois = new ObjectInputStream(s.getInputStream());
			JOptionPane.showMessageDialog(null, "Conexion exitosa con el cliente", "COMO&COMO Servidor", JOptionPane.INFORMATION_MESSAGE);
			System.out.println("Servidor~# Conexi�n exitosa.");
			this.readLine();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public void closeConnection(){
		try{
			oos.close();
			ois.close();
			s.close();
			ss.close();
		}catch(IOException e){
			e.printStackTrace();
		}
	}
	
	public void readLine(){
		while(true){
			try{
				Object aux = ois.readObject();
				if(aux != null && aux instanceof String){
					// Realiza el la actualizaci�n.
					bdConnection.getStament().executeUpdate(""+aux);
					ventana.fillAllTables();
				}
				Thread.sleep(30);
			}catch(InterruptedException | ClassNotFoundException | IOException | SQLException e){
				e.printStackTrace();
			}
		}
	}
	
	public void writeLine(String query){
		try {
			oos.writeObject(query);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
